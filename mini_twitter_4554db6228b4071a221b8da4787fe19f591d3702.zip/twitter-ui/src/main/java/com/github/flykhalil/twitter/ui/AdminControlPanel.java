package com.github.flykhalil.twitter.ui;

import com.github.flykhalil.twitter.core.exception.DataAccessException;
import com.github.flykhalil.twitter.core.model.IAdminPanel;
import com.github.flykhalil.twitter.core.model.IGroup;
import com.github.flykhalil.twitter.core.model.IUser;
import com.github.flykhalil.twitter.core.model.impl.AdminPanel;
import com.github.flykhalil.twitter.core.model.impl.Group;
import com.github.flykhalil.twitter.core.model.impl.User;
import com.github.flykhalil.twitter.core.storage.RepositoryHolder;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.UUID;
import java.util.concurrent.Callable;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 10.11.2020
 * Time: 1:36
 */
public class AdminControlPanel extends JFrame {

    private final JFrame root;

    private JPanel panelMain;

    private JTree treeGroups;

    private JTextField textFieldUserId;

    private JTextField textFieldGroupId;

    private JButton buttonAddUser;

    private JButton buttonAddGroup;

    private JButton buttonShowUserTotal;

    private JButton buttonShowGroupTotal;

    private JButton buttonShowTweetsTotal;

    private JButton buttonShowPositivePercentage;

    private JButton buttonOpenUserView;

    private IAdminPanel adminPanel;

    private UUID saveGroupListenerId;

    public AdminControlPanel(final String title) {
        super(title);
        root = this;
        try {
            adminPanel = new AdminPanel();
            setContentPane(panelMain);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setSize(800, 600);
            setResizable(false);
            updateComponents();
            Callable<Void> updateCallable = () -> {
                updateComponents();
                return null;
            };
            saveGroupListenerId = RepositoryHolder.getGroupRepository().addSaveListener(updateCallable);
        }
        catch (Exception e) {
            DialogUtil.showErrorMsg(root, e);
        }
        buttonAddUser.addActionListener(e -> {
            try {
                IGroup selectedGroup = getSelectedGroup();
                TextFieldView textFieldView = new TextFieldView(root, "Add User", "Create User");
                textFieldView.setVisible(true);
                String username = textFieldView.getText();
                String userIdString = textFieldUserId.getText();
                if (username != null && !username.isEmpty() && userIdString != null && !userIdString.isEmpty()) {
                    saveUser(selectedGroup, userIdString, username);
                    DialogUtil.showInfo(root, String.format("User \"%s\" with id %s was created.", username, userIdString));
                }
            }
            catch (Exception exception) {
                DialogUtil.showErrorMsg(root, exception);
            }
        });
        buttonAddGroup.addActionListener(e -> {
            try {
                IGroup selectedGroup = getSelectedGroup();
                TextFieldView textFieldView = new TextFieldView(root, "Add Group", "Create Group");
                textFieldView.setVisible(true);
                String groupName = textFieldView.getText();
                String groupId = textFieldGroupId.getText();
                if (groupName != null && !groupName.isEmpty() && groupId != null && !groupId.isEmpty()) {
                    saveGroup(selectedGroup, groupId, groupName);
                    DialogUtil.showInfo(root, String.format("Group \"%s\" with id %s was created.", groupName, groupId));
                }
            }
            catch (Exception exception) {
                DialogUtil.showErrorMsg(root, exception);
            }
        });
        buttonShowUserTotal.addActionListener(e -> {
            try {
                DialogUtil.showInfo(root, String.format("Total number of users is %s", adminPanel.getTotalNumberOfUsers()));
            }
            catch (Exception exception) {
                DialogUtil.showErrorMsg(root, exception);
            }
        });
        buttonShowGroupTotal.addActionListener(e -> {
            try {
                DialogUtil.showInfo(root, String.format("Total number of groups is %s", adminPanel.getTotalNumberOfGroups()));
            }
            catch (Exception exception) {
                DialogUtil.showErrorMsg(root, exception);
            }
        });
        buttonShowTweetsTotal.addActionListener(e -> {
            try {
                DialogUtil.showInfo(root, String.format("Total number of tweets is %s", adminPanel.getTotalNumberOfTweets()));
            }
            catch (Exception exception) {
                DialogUtil.showErrorMsg(root, exception);
            }
        });
        buttonShowPositivePercentage.addActionListener(e -> {
            try {
                DialogUtil.showInfo(root, String.format("Positive percentage of tweets is %.2f%%",
                                                        adminPanel.getPositivePercentageOfTweets() * 100));
            }
            catch (Exception exception) {
                DialogUtil.showErrorMsg(root, exception);
            }
        });
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(final WindowEvent e) {
                super.windowClosing(e);
                RepositoryHolder.getGroupRepository().removeListener(saveGroupListenerId);
            }
        });
        buttonOpenUserView.addActionListener(e -> {
            try {
                IUser selectedUser = getSelectedUser();
                UserView userView = new UserView(selectedUser);
                userView.setVisible(true);
            }
            catch (Exception exception) {
                DialogUtil.showErrorMsg(root, exception);
            }
        });
    }

    public static void main(String[] args) {
        AdminControlPanel frame = new AdminControlPanel("Admin Control Panel");
        frame.setVisible(true);
    }

    private void updateComponents() {
        try {
            treeGroups.setModel(null);
            IGroup rootGroup = RepositoryHolder.getGroupRepository().findByName("ROOT");
            if (rootGroup == null) {
                throw new IllegalStateException("ROOT group doesn't exist");
            }
            DefaultMutableTreeNode root = createGroupTree(rootGroup);
            TreeModel treeModel = new DefaultTreeModel(root);
            treeGroups.setModel(treeModel);
        }
        catch (Exception e) {
            DialogUtil.showErrorMsg(root, e);
        }
    }

    private void saveUser(final IGroup selectedGroup, final String userIdString, final String username)
            throws DataAccessException {
        long userId = Long.parseLong(userIdString);
        selectedGroup.addUserId(userId);
        IUser user = new User(userId, username);
        RepositoryHolder.getUserRepository().save(userId, user);
        RepositoryHolder.getGroupRepository().save(selectedGroup.getId(), selectedGroup);
    }

    private void saveGroup(final IGroup selectedGroup, final String groupIdString, final String groupName)
            throws DataAccessException {
        long groupId = Long.parseLong(groupIdString);
        selectedGroup.addSubGroupId(groupId);
        IGroup group = new Group(groupId, groupName);
        RepositoryHolder.getGroupRepository().save(groupId, group);
        RepositoryHolder.getGroupRepository().save(selectedGroup.getId(), selectedGroup);
    }

    private DefaultMutableTreeNode createGroupTree(final IGroup rootGroup) throws DataAccessException {
        DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode(rootGroup);
        for (Long usersId : rootGroup.getUsersIds()) {
            IUser user = RepositoryHolder.getUserRepository().findById(usersId);
            rootNode.add(new DefaultMutableTreeNode(user));
        }
        for (Long subGroupsId : rootGroup.getSubGroupsIds()) {
            IGroup group = RepositoryHolder.getGroupRepository().findById(subGroupsId);
            rootNode.add(createGroupTree(group));
        }
        return rootNode;
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     */
    private void $$$setupUI$$$() {
        panelMain = new JPanel();
        panelMain.setLayout(
                new com.intellij.uiDesigner.core.GridLayoutManager(6, 3, new Insets(10, 10, 10, 10), -1, -1, true, true));
        treeGroups = new JTree();
        panelMain.add(treeGroups, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 6, 1,
                                                                                   com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER,
                                                                                   com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH,
                                                                                   com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED,
                                                                                   com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW,
                                                                                   null, new Dimension(205, 50), null, 0, false));
        textFieldUserId = new JTextField();
        panelMain.add(textFieldUserId, new com.intellij.uiDesigner.core.GridConstraints(0, 1, 1, 1,
                                                                                        com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST,
                                                                                        com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL,
                                                                                        com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW,
                                                                                        com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED,
                                                                                        null, new Dimension(220, 30), null, 0,
                                                                                        false));
        textFieldGroupId = new JTextField();
        panelMain.add(textFieldGroupId, new com.intellij.uiDesigner.core.GridConstraints(1, 1, 1, 1,
                                                                                         com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST,
                                                                                         com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL,
                                                                                         com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW,
                                                                                         com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED,
                                                                                         null, new Dimension(220, 30), null, 0,
                                                                                         false));
        buttonAddUser = new JButton();
        buttonAddUser.setText("Add User");
        panelMain.add(buttonAddUser, new com.intellij.uiDesigner.core.GridConstraints(0, 2, 1, 1,
                                                                                      com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER,
                                                                                      com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL,
                                                                                      1,
                                                                                      com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED,
                                                                                      null, null, null, 0, false));
        buttonAddGroup = new JButton();
        buttonAddGroup.setText("Add Group");
        panelMain.add(buttonAddGroup, new com.intellij.uiDesigner.core.GridConstraints(1, 2, 1, 1,
                                                                                       com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER,
                                                                                       com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL,
                                                                                       1,
                                                                                       com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED,
                                                                                       null, null, null, 0, false));
        buttonShowUserTotal = new JButton();
        buttonShowUserTotal.setText("Show User Total");
        panelMain.add(buttonShowUserTotal, new com.intellij.uiDesigner.core.GridConstraints(4, 1, 1, 1,
                                                                                            com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER,
                                                                                            com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL,
                                                                                            1,
                                                                                            com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED,
                                                                                            null, new Dimension(220, 30), null, 0,
                                                                                            false));
        buttonShowGroupTotal = new JButton();
        buttonShowGroupTotal.setText("Show Group Total");
        panelMain.add(buttonShowGroupTotal, new com.intellij.uiDesigner.core.GridConstraints(4, 2, 1, 1,
                                                                                             com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER,
                                                                                             com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL,
                                                                                             1,
                                                                                             com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED,
                                                                                             null, null, null, 0, false));
        buttonShowTweetsTotal = new JButton();
        buttonShowTweetsTotal.setText("Show Tweets Total");
        panelMain.add(buttonShowTweetsTotal, new com.intellij.uiDesigner.core.GridConstraints(5, 1, 1, 1,
                                                                                              com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER,
                                                                                              com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL,
                                                                                              1,
                                                                                              com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED,
                                                                                              null, new Dimension(220, 30), null,
                                                                                              0, false));
        buttonShowPositivePercentage = new JButton();
        buttonShowPositivePercentage.setText("Show Positive Percentage");
        panelMain.add(buttonShowPositivePercentage, new com.intellij.uiDesigner.core.GridConstraints(5, 2, 1, 1,
                                                                                                     com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER,
                                                                                                     com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL,
                                                                                                     1,
                                                                                                     com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED,
                                                                                                     null, null, null, 0, false));
        buttonOpenUserView = new JButton();
        buttonOpenUserView.setText("Open User View");
        panelMain.add(buttonOpenUserView, new com.intellij.uiDesigner.core.GridConstraints(2, 1, 1, 2,
                                                                                           com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER,
                                                                                           com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL,
                                                                                           1,
                                                                                           com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED,
                                                                                           null, null, null, 0, false));
    }

    /**
     *
     */
    public JComponent $$$getRootComponent$$$() { return panelMain; }

    private IUser getSelectedUser() {
        DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) treeGroups.getLastSelectedPathComponent();
        if (selectedNode == null) {
            throw new IllegalArgumentException("Please select a user first");
        }
        Object userObj = selectedNode.getUserObject();
        IUser result;
        if (userObj instanceof IUser) {
            result = (IUser) userObj;
        }
        else {
            throw new IllegalArgumentException("Please select a group");
        }
        return result;
    }

    private IGroup getSelectedGroup() {
        DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) treeGroups.getLastSelectedPathComponent();
        if (selectedNode == null) {
            throw new IllegalArgumentException("Please select a group first");
        }
        Object userObj = selectedNode.getUserObject();
        IGroup result;
        if (userObj instanceof IGroup) {
            result = (IGroup) userObj;
        }
        else if (userObj instanceof IUser) {
            DefaultMutableTreeNode parentNode = (DefaultMutableTreeNode) selectedNode.getParent();
            userObj = parentNode.getUserObject();
            if (userObj instanceof IGroup) {
                result = (IGroup) userObj;
            }
            else {
                throw new IllegalArgumentException("Unknown node type");
            }
        }
        else {
            throw new IllegalArgumentException("Unknown node type");
        }
        return result;
    }
}
