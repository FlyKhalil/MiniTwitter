package com.github.flykhalil.twitter.ui;

import com.github.flykhalil.twitter.core.exception.DataAccessException;
import com.github.flykhalil.twitter.core.model.IFeed;
import com.github.flykhalil.twitter.core.model.ITweet;
import com.github.flykhalil.twitter.core.model.IUser;
import com.github.flykhalil.twitter.core.model.impl.Feed;
import com.github.flykhalil.twitter.core.model.impl.Tweet;
import com.github.flykhalil.twitter.core.storage.RepositoryHolder;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.*;
import java.util.List;
import java.util.concurrent.Callable;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 10.11.2020
 * Time: 2:19
 */
public class UserView extends JFrame {

    private final JFrame parent;

    private final IFeed feed;

    private final UUID saveUserListenerId;

    private final UUID saveTweetListenerId;

    private JTextField textFieldFollowingUserId;

    private JButton buttonFollowUser;

    private JList<IUser> listCurrentFollowing;

    private JTextField textFieldTweetMessage;

    private JButton buttonPostTweet;

    private JList<ITweet> listNewsFeed;

    private JPanel panelMain;

    public UserView(final IUser user) {
        this.parent = this;
        this.feed = new Feed();
        setSize(800, 600);
        setResizable(false);
        setContentPane(panelMain);
        setTitle(user.toString());
        Callable<Void> updateComponentsCallable = () -> {
            try {
                updateComponents(user);
            }
            catch (Exception e) {
                DialogUtil.showErrorMsg(parent, e);
            }
            return null;
        };
        this.saveTweetListenerId = RepositoryHolder.getTweetRepository().addSaveListener(updateComponentsCallable);
        this.saveUserListenerId = RepositoryHolder.getUserRepository().addSaveListener(updateComponentsCallable);
        try {
            updateComponents(user);
        }
        catch (Exception e) {
            DialogUtil.showErrorMsg(parent, e);
        }
        buttonFollowUser.addActionListener(e -> {
            try {
                String followingUserIdString = textFieldFollowingUserId.getText();
                followUser(user, Long.parseLong(followingUserIdString));
            }
            catch (Exception exception) {
                DialogUtil.showErrorMsg(parent, exception);
            }
        });
        buttonPostTweet.addActionListener(e -> {
            String tweetText = textFieldTweetMessage.getText();
            try {
                postTweet(user, tweetText);
            }
            catch (Exception exception) {
                DialogUtil.showErrorMsg(parent, exception);
            }
        });
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(final WindowEvent e) {
                super.windowClosing(e);
                RepositoryHolder.getTweetRepository().removeListener(saveTweetListenerId);
                RepositoryHolder.getUserRepository().removeListener(saveUserListenerId);
            }
        });
    }

    private void updateComponents(final IUser user) throws DataAccessException {
        updateFeed(user);
        updateFollowingList(user);
    }

    private void followUser(final IUser user, final long followingUserId) throws DataAccessException {
        IUser following = RepositoryHolder.getUserRepository().findById(followingUserId);
        if (following == null) {
            throw new IllegalArgumentException("No such user with id " + followingUserId);
        }
        user.addFollowingUserId(following.getId());
        following.addFollowerUserId(user.getId());
        RepositoryHolder.getUserRepository().save(user.getId(), user);
        RepositoryHolder.getUserRepository().save(following.getId(), following);
    }

    private void postTweet(final IUser user, final String tweetText) throws DataAccessException {
        if (tweetText == null || tweetText.isEmpty()) {
            throw new IllegalArgumentException("Can't post an empty tweet");
        }
        ITweet tweet = new Tweet(user.getId(), tweetText);
        RepositoryHolder.getTweetRepository().save(UUID.randomUUID(), tweet);
    }

    private void updateFeed(final IUser user) throws DataAccessException {
        Set<ITweet> tweets = feed.getFeedForUser(user.getId());
        List<ITweet> sortedTweets = new ArrayList<>(tweets);
        sortedTweets.sort(Comparator.comparing(ITweet::getTweetTime));
        DefaultListModel<ITweet> listModel = new DefaultListModel<>();
        for (ITweet tweet : sortedTweets) {
            listModel.addElement(tweet);
        }
        listNewsFeed.setModel(listModel);
    }

    private void updateFollowingList(final IUser user) throws DataAccessException {
        DefaultListModel<IUser> listModel = new DefaultListModel<>();
        Set<Long> followingUserIds = RepositoryHolder.getUserRepository().findById(user.getId()).getFollowingUserIds();
        for (Long followingUserId : followingUserIds) {
            listModel.addElement(RepositoryHolder.getUserRepository().findById(followingUserId));
        }
        listCurrentFollowing.setModel(listModel);
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     */
    private void $$$setupUI$$$() {
        panelMain = new JPanel();
        panelMain.setLayout(
                new com.intellij.uiDesigner.core.GridLayoutManager(4, 2, new Insets(10, 10, 10, 10), -1, -1, true, true));
        textFieldFollowingUserId = new JTextField();
        panelMain.add(textFieldFollowingUserId, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1,
                                                                                                 com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST,
                                                                                                 com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL,
                                                                                                 com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW,
                                                                                                 com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED,
                                                                                                 null, new Dimension(150, -1),
                                                                                                 null, 0, false));
        listCurrentFollowing = new JList();
        panelMain.add(listCurrentFollowing, new com.intellij.uiDesigner.core.GridConstraints(1, 0, 1, 2,
                                                                                             com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER,
                                                                                             com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH,
                                                                                             com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW,
                                                                                             com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW,
                                                                                             null, new Dimension(150, 50), null,
                                                                                             0, false));
        buttonFollowUser = new JButton();
        buttonFollowUser.setText("Follow User");
        panelMain.add(buttonFollowUser, new com.intellij.uiDesigner.core.GridConstraints(0, 1, 1, 1,
                                                                                         com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER,
                                                                                         com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL,
                                                                                         com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK |
                                                                                                 com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW,
                                                                                         com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED,
                                                                                         null, null, null, 0, false));
        textFieldTweetMessage = new JTextField();
        panelMain.add(textFieldTweetMessage, new com.intellij.uiDesigner.core.GridConstraints(2, 0, 1, 1,
                                                                                              com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST,
                                                                                              com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL,
                                                                                              com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW,
                                                                                              com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED,
                                                                                              null, new Dimension(150, -1), null,
                                                                                              0, false));
        buttonPostTweet = new JButton();
        buttonPostTweet.setText("Post Tweet");
        panelMain.add(buttonPostTweet, new com.intellij.uiDesigner.core.GridConstraints(2, 1, 1, 1,
                                                                                        com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER,
                                                                                        com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL,
                                                                                        com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK |
                                                                                                com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW,
                                                                                        com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED,
                                                                                        null, null, null, 0, false));
        listNewsFeed = new JList();
        panelMain.add(listNewsFeed, new com.intellij.uiDesigner.core.GridConstraints(3, 0, 1, 2,
                                                                                     com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER,
                                                                                     com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH,
                                                                                     com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW,
                                                                                     com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW,
                                                                                     null, new Dimension(150, 50), null, 0,
                                                                                     false));
    }

    /**
     *
     */
    public JComponent $$$getRootComponent$$$() { return panelMain; }
}
