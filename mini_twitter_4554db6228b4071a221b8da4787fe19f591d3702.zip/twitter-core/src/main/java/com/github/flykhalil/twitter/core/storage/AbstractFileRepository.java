package com.github.flykhalil.twitter.core.storage;

import com.github.flykhalil.twitter.core.config.Constants;
import com.github.flykhalil.twitter.core.exception.DataAccessException;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 09.11.2020
 * Time: 20:27
 */
public abstract class AbstractFileRepository <T extends Serializable, ID extends Serializable> implements Repository<T, ID> {

    private final File repositoryFile;

    private final Map<UUID, Callable<Void>> saveListeners = new HashMap<>();

    private final ReentrantLock fileLock = new ReentrantLock();

    public AbstractFileRepository() throws IOException, DataAccessException {
        File repositoryDirectory = new File(Constants.REPOSITORIES_DIRECTORY);
        repositoryFile = new File(repositoryDirectory.getAbsolutePath() + File.separator + this.getClass().getSimpleName());
        if (!repositoryDirectory.exists()) {
            if (!repositoryDirectory.mkdirs()) {
                throw new IOException("Couldn't create directory for repository " + repositoryDirectory.getAbsolutePath());
            }
        }
        if (!repositoryFile.exists()) {
            if (!repositoryFile.createNewFile()) {
                throw new IOException("Couldn't create repository file for repository " + repositoryFile.getAbsolutePath());
            }
            else {
                serialize(new HashMap<>());
            }
        }
    }

    private void serialize(final Map<ID, T> map) throws DataAccessException {
        try {
            fileLock.lock();
            try (FileOutputStream fileOutputStream = new FileOutputStream(repositoryFile);
                 ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream)) {
                objectOutputStream.writeObject(map);
            }
            catch (IOException e) {
                throw new DataAccessException("Couldn't access repository", e);
            }
        }
        finally {
            fileLock.unlock();
        }
    }

    @Override
    public UUID addSaveListener(final Callable<Void> listener) {
        UUID listenerId = UUID.randomUUID();
        saveListeners.put(listenerId, listener);
        return listenerId;
    }

    @Override
    public void removeListener(final UUID listenerId) {
        saveListeners.remove(listenerId);
    }

    @Override
    public void save(final ID id, final T obj) throws DataAccessException {
        Map<ID, T> map = deserialize();
        map.put(id, obj);
        serialize(map);
        invokeSaveListeners();
    }

    @Override
    public T findById(final ID id) throws DataAccessException {
        Map<ID, T> map = deserialize();
        T result;
        result = map.getOrDefault(id, null);
        return result;
    }

    @Override
    public Map<ID, T> findAll() throws DataAccessException {
        return deserialize();
    }

    private Map<ID, T> deserialize() throws DataAccessException {
        Map<ID, T> map;
        try {
            fileLock.lock();
            try (FileInputStream fileInputStream = new FileInputStream(repositoryFile);
                 ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream)) {
                Object obj = objectInputStream.readObject();
                if (!(obj instanceof Map)) {
                    throw new IllegalStateException("Deserialized object is not Map");
                }
                map = (Map<ID, T>) obj;
            }
            catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
                throw new DataAccessException("Couldn't access file repository", e);
            }
        }
        finally {
            fileLock.unlock();
        }
        return map;
    }

    private void invokeSaveListeners() {
        for (Callable<Void> value : saveListeners.values()) {
            try {
                value.call();
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
        }
    }
}
