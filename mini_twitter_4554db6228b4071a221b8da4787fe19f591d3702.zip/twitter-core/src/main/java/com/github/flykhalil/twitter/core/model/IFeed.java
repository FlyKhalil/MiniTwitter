package com.github.flykhalil.twitter.core.model;

import com.github.flykhalil.twitter.core.exception.DataAccessException;

import java.io.Serializable;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 09.11.2020
 * Time: 1:19
 */
public interface IFeed extends Serializable {

    void postTweet(ITweet tweet) throws DataAccessException;

    Set<ITweet> getFeedForUser(long userId) throws DataAccessException;

    Set<ITweet> getAllTweets() throws DataAccessException;
}
