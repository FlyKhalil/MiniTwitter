package com.github.flykhalil.twitter.core.model.impl;

import com.github.flykhalil.twitter.core.exception.DataAccessException;
import com.github.flykhalil.twitter.core.model.IFeed;
import com.github.flykhalil.twitter.core.model.ITweet;
import com.github.flykhalil.twitter.core.model.IUser;
import com.github.flykhalil.twitter.core.storage.RepositoryHolder;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 09.11.2020
 * Time: 22:32
 */
public class Feed implements IFeed {

    @Override
    public void postTweet(final ITweet tweet) throws DataAccessException {
        RepositoryHolder.getTweetRepository().save(tweet.getId(), tweet);
    }

    @Override
    public Set<ITweet> getFeedForUser(final long userId) throws DataAccessException {
        IUser user = RepositoryHolder.getUserRepository().findById(userId);
        if (user == null) {
            throw new IllegalArgumentException("No such user with id " + userId);
        }
        Set<ITweet> otherUsersTweets = RepositoryHolder.getTweetRepository().findTweetsByOwnerIdIn(user.getFollowingUserIds());
        Set<ITweet> ownerTweets = RepositoryHolder.getTweetRepository().findTweetsByOwnerId(userId);
        otherUsersTweets.addAll(ownerTweets);
        return otherUsersTweets;
    }

    @Override
    public Set<ITweet> getAllTweets() throws DataAccessException {
        return new HashSet<>(RepositoryHolder.getTweetRepository().findAll().values());
    }
}
