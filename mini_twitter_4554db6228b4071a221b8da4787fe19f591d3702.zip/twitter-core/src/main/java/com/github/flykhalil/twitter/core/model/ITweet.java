package com.github.flykhalil.twitter.core.model;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.UUID;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 09.11.2020
 * Time: 1:21
 */
public interface ITweet extends Serializable {

    UUID getId();

    long getOwnerId();

    String getTweetText();

    ZonedDateTime getTweetTime();
}
