package com.github.flykhalil.twitter.core.storage;

import com.github.flykhalil.twitter.core.exception.DataAccessException;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 09.11.2020
 * Time: 22:22
 */
public final class RepositoryHolder {

    private static final TweetRepository TWEET_REPOSITORY;

    private static final UserRepository USER_REPOSITORY;

    private static final GroupRepository GROUP_REPOSITORY;

    static {
        try {
            TWEET_REPOSITORY = new TweetRepository();
            USER_REPOSITORY = new UserRepository();
            GROUP_REPOSITORY = new GroupRepository();
        }
        catch (IOException | DataAccessException e) {
            throw new RuntimeException(e);
        }
    }

    public static TweetRepository getTweetRepository() {
        return TWEET_REPOSITORY;
    }

    public static UserRepository getUserRepository() {
        return USER_REPOSITORY;
    }

    public static GroupRepository getGroupRepository() {
        return GROUP_REPOSITORY;
    }
}
