package com.github.flykhalil.twitter.core.model.impl;

import com.github.flykhalil.twitter.core.exception.DataAccessException;
import com.github.flykhalil.twitter.core.model.IGroup;
import com.github.flykhalil.twitter.core.storage.RepositoryHolder;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 09.11.2020
 * Time: 0:50
 */
public class Group implements IGroup {

    private final long id;

    private final Set<Long> subGroupsIds = new HashSet<>();

    private final Set<Long> usersIds = new HashSet<>();

    private final String name;

    public Group(final long id, final String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public void addSubGroupId(final long subGroupId) throws DataAccessException {
        Optional<IGroup> optionalIGroup = RepositoryHolder.getGroupRepository().findAll().values().stream()
                                                          .filter(group -> group.getSubGroupsIds().contains(subGroupId))
                                                          .findFirst();
        if (optionalIGroup.isPresent()) {
            throw new IllegalArgumentException("Group is already contained in another group " + optionalIGroup.get().getName());
        }
        subGroupsIds.add(subGroupId);
    }

    @Override
    public void addUserId(final long userId) throws DataAccessException {
        Optional<IGroup> optionalIGroup = RepositoryHolder.getGroupRepository().findAll().values().stream()
                                                          .filter(group -> group.getUsersIds().contains(userId)).findFirst();
        if (optionalIGroup.isPresent()) {
            throw new IllegalArgumentException("User is already contained in another group " + optionalIGroup.get().getName());
        }
        usersIds.add(userId);
    }

    @Override
    public long getId() {
        return id;
    }

    @Override
    public Set<Long> getSubGroupsIds() {
        return Collections.unmodifiableSet(subGroupsIds);
    }

    @Override
    public Set<Long> getUsersIds() {
        return Collections.unmodifiableSet(usersIds);
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, subGroupsIds, usersIds, name);
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Group group = (Group) o;
        return id == group.id && Objects.equals(subGroupsIds, group.subGroupsIds) && Objects.equals(usersIds, group.usersIds) &&
                Objects.equals(name, group.name);
    }

    @Override
    public String toString() {
        return "Group:" + id + " - " + name;
    }
}
