package com.github.flykhalil.twitter.core.storage;

import com.github.flykhalil.twitter.core.exception.DataAccessException;
import com.github.flykhalil.twitter.core.model.ITweet;

import java.io.IOException;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 09.11.2020
 * Time: 22:20
 */
public class TweetRepository extends AbstractFileRepository<ITweet, UUID> {

    public TweetRepository() throws IOException, DataAccessException {
        super();
    }

    public Set<ITweet> findTweetsByOwnerIdIn(final Set<Long> userIds) throws DataAccessException {
        return findAll().values().stream().filter(tweet -> userIds.contains(tweet.getOwnerId())).collect(Collectors.toSet());
    }

    public Set<ITweet> findTweetsByOwnerId(final Long userId) throws DataAccessException {
        return findAll().values().stream().filter(tweet -> userId == tweet.getOwnerId()).collect(Collectors.toSet());
    }
}
