package com.github.flykhalil.twitter.core.model.impl;

import com.github.flykhalil.twitter.core.model.IUser;

import java.util.Collections;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 09.11.2020
 * Time: 0:49
 */
public class User implements IUser {

    private final Set<Long> followersUserIds = new HashSet<>();

    private final Set<Long> followingUserIds = new HashSet<>();

    private final long id;

    private final String name;

    public User(final long id, final String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public void addFollowerUserId(final long followerUserId) {
        followersUserIds.add(followerUserId);
    }

    @Override
    public void addFollowingUserId(final long followerUserId) {
        if (followerUserId != id) {
            followingUserIds.add(followerUserId);
        }
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public long getId() {
        return id;
    }

    @Override
    public Set<Long> getFollowersUserIds() {
        return Collections.unmodifiableSet(followersUserIds);
    }

    @Override
    public Set<Long> getFollowingUserIds() {
        return Collections.unmodifiableSet(followingUserIds);
    }

    @Override
    public int hashCode() {
        return Objects.hash(followersUserIds, followingUserIds, id, name);
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        User user = (User) o;
        return id == user.id && Objects.equals(followersUserIds, user.followersUserIds) &&
                Objects.equals(followingUserIds, user.followingUserIds) && Objects.equals(name, user.name);
    }

    @Override
    public String toString() {
        return "User:" + id + " - " + name;
    }
}
