package com.github.flykhalil.twitter.core.config;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 09.11.2020
 * Time: 20:22
 */
public final class Constants {

    public static final String REPOSITORIES_DIRECTORY = "repositories";
}
