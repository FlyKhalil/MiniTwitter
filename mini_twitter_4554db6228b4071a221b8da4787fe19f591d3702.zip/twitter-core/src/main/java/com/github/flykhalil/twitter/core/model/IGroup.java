package com.github.flykhalil.twitter.core.model;

import com.github.flykhalil.twitter.core.exception.DataAccessException;

import java.io.Serializable;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: rsv
 * Date: 09.11.2020
 * Time: 0:50
 */
public interface IGroup extends Serializable {

    void addSubGroupId(long subGroupId) throws DataAccessException;

    void addUserId(long userId) throws DataAccessException;

    long getId();

    Set<Long> getSubGroupsIds();

    Set<Long> getUsersIds();

    String getName();
}
